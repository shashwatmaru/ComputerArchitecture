package stages;

import common.CPUContext;
import common.Instruction;

public class PRFStage extends Stage {

	public PRFStage(CPUContext cpuContext) {
		super(cpuContext);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute(int currentExecutionCycle) {
		// TODO Auto-generated method stub
//		Instruction instr = cpuContext.getReorderBuffer().getReorderBufferQueue().peek();
		
	}

}
