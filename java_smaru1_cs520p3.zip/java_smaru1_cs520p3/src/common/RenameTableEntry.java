package common;

public class RenameTableEntry {
	
	private String architecturalRegister;
	private String physicalRegister;
	
	
	public String getArchitecturalRegister() {
		return architecturalRegister;
	}
	public void setArchitecturalRegister(String architecturalRegister) {
		this.architecturalRegister = architecturalRegister;
	}
	public String getPhysicalRegister() {
		return physicalRegister;
	}
	public void setPhysicalRegister(String physicalRegister) {
		this.physicalRegister = physicalRegister;
	}

}
